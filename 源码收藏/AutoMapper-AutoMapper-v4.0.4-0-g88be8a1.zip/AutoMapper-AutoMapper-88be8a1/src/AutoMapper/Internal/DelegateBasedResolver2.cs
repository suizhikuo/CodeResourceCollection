namespace AutoMapper
{
    using System;

}