namespace AutoMapper.Internal
{
    public interface IProxyGeneratorFactory
    {
        IProxyGenerator Create();
    }
}