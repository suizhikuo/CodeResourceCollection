namespace AutoMapper.Internal
{
    public interface IEnumNameValueMapperFactory
    {
        IEnumNameValueMapper Create();
    }
}