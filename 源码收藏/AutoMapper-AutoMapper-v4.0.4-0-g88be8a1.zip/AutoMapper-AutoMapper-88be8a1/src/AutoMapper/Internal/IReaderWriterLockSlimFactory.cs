namespace AutoMapper.Internal
{
    public interface IReaderWriterLockSlimFactory
    {
        IReaderWriterLockSlim Create();
    }
}