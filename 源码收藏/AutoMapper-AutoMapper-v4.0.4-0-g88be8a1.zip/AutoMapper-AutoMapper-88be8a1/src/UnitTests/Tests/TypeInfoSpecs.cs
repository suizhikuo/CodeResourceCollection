namespace AutoMapper.UnitTests.Tests
{
    public class TypeInfoSpecs
    {
        
    }
}