package com.bufoon.util;

public class Constants {

	public static String LOGIN_USER; //登录用户
	public final static int PAGE_SIZE = 10; //分页 一页显示的行数
}
