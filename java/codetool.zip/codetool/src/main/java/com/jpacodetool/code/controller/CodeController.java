package com.jpacodetool.code.controller;

import com.jpacodetool.code.codeutil.CodeGenerator;
import com.jpacodetool.code.codeutil.Column;
import com.jpacodetool.code.util.StringUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.*;
import java.util.*;

@RestController
@RequestMapping("/code")
public class CodeController {

	@GetMapping("/table")
	public List<Map<String, String>> getTables(@RequestParam Map<String, String> params) throws Exception {
		String userName = params.get("userName");
		String password = params.get("password");
		String driver = params.get("driver");
		String url = params.get("url");
		String databaseName = params.get("databaseName");
		Connection conn = getConnection(userName, password, driver, url);
		String sql = "select `table_name`,table_comment,create_time from information_schema.tables where table_schema='"
				+ databaseName + "' and LOWER(table_type)='base table' order by `table_name` asc";
		PreparedStatement ps = conn.prepareStatement(sql);

		System.out.println("sql : " + sql);

		ResultSet rs = ps.executeQuery();
		List<Map<String, String>> tables = new ArrayList<>();
		while (rs.next()) {
			Map<String, String> temp = new HashMap<>(3);
			temp.put("tableName", rs.getString("table_name"));
			temp.put("tableComment", rs.getString("table_comment"));
			temp.put("createTime", rs.getString("create_time"));
			tables.add(temp);
		}
		closeConnection(conn, ps, rs);
		return tables;
	}

	@GetMapping("/genaretorWithMybatis")
	public Map genaretorWithMybatis(@RequestParam Map<String, String> params) throws Exception {
		params.put("mybatis", "with");
		return genaretor(params);
	}

	@GetMapping("/genaretor")
	public Map genaretor(@RequestParam Map<String, String> params) throws Exception {
		Map res = new HashMap(2);
		String mybatis = params.get("mybatis");
		String tableNames = params.get("tableName");
		String module = params.get("module");
		String javaSource = params.get("javaSource");
		String userName = params.get("userName");
		String password = params.get("password");
		String driver = params.get("driver");
		String url = params.get("url");
		String databaseName = params.get("databaseName");
		String pkgPrefix = params.get("pkgPrefix");
		String tablePrefix = params.get("tablePrefix");
		String maName = params.get("masterName");
		String relName = params.get("relName");
		String write = params.get("write");
		String list = params.get("list");
		String search = params.get("search");
		String rel = params.get("rel");
		CodeGenerator code = new CodeGenerator();
		maName = maName.trim();
		code.setTableName(maName);
		code.setTablePrefix(tablePrefix);
		// 数据库读取配置信息
		code.setTableComment(getTableComment(databaseName, maName, userName, password, driver, url));
		code.initCodeTool(getLsColumns(maName, userName, password, driver, url),
				getColumns(write, maName, relName + maName, userName, password, driver, url),
				getColumns(list, maName, relName + maName, userName, password, driver, url),
				getColumns(search, maName, relName + maName, userName, password, driver, url));
		code.createCodeByConf(params);
		if (relName != null && !"".equals(relName)) {
			code.setRel(getRelKey(relName, userName, password, driver, url));
		}
		res.put("result", "success");
		res.put("msg", "success");
		return res;
	}

	private Connection getConnection(String userName, String password, String driver, String url) throws Exception {
		Properties localProperties = new Properties();
		localProperties.put("remarksReporting", "true");
		localProperties.put("user", userName);
		localProperties.put("password", password);
		// orcl为数据库的SID
		Class.forName(driver).newInstance();
		Connection conn = DriverManager.getConnection(url, localProperties);
		return conn;
	}

	private void closeConnection(Connection conn, PreparedStatement ps, ResultSet rs) throws Exception {
		if (rs != null) {
			rs.close();
		}
		if (ps != null) {
			ps.close();
		}
		if (conn != null) {
			conn.close();
		}
	}

	@GetMapping("/columns")
	private List<List<Column>> columns(String maName, String relName, String userName, String password, String driver,
			String url) throws Exception {
		List<List<Column>> columns = new ArrayList<>();
		List<Column> maCol = getLsColumns(maName, userName, password, driver, url);
		columns.add(maCol);
		if (relName != null && !("").equals(relName)) {
			String[] rels = relName.split(",");
			List<Column> relCol = new ArrayList<>();
			for (String rel : rels) {
				List<Column> relTemp = getLsColumns(rel, userName, password, driver, url);
				relCol.addAll(relTemp);
			}
			columns.add(relCol);
		}
		return columns;
	}

	@GetMapping("/relation")
	private List<String> relation(String relName) {
		String[] rels = relName.split(",");
		List<String> list = new ArrayList<>();
		for (String rel : rels) {
			list.add(rel);
		}
		return list;
	}

	private List<Column> getLsColumns(String tableName, String userName, String password, String driver, String url)
			throws Exception {
		Connection conn = getConnection(userName, password, driver, url);
		List<Column> lsColumns = new ArrayList<Column>(10);
		PreparedStatement stmt = conn.prepareStatement("select *  from " + tableName + " where 1=0 ");
		ResultSet resultSet = stmt.executeQuery();
		ResultSetMetaData rsmd = resultSet.getMetaData();
		int n = rsmd.getColumnCount();
		for (int i = 1; i <= n; i++) {
			String colName = rsmd.getColumnName(i);
			String fieldName = StringUtil.replaceUnderlineAndfirstToUpper(colName, "_", "");
			String dataType = rsmd.getColumnClassName(i);
			if ("java.math.BigDecimal".equals(dataType) && rsmd.getScale(i) == 0) {
				dataType = "Long";
			}
			if ("oracle.sql.CLOB".equals(dataType)) {
				dataType = "String";
			}
			if ("java.lang.Boolean".equals(dataType)) {
				dataType = "java.lang.Integer";
			}

			Column column = new Column();
			column.setName(colName);
			column.setJavaName(fieldName);
			column.setDataType(
					dataType.endsWith("Timestamp") || dataType.endsWith("Date") ? "java.util.Date" : dataType);
			column.setPrecision(String.valueOf(rsmd.getPrecision(i)));
			column.setScale(String.valueOf(rsmd.getScale(i)));
			column.setLength(String.valueOf(rsmd.getColumnDisplaySize(i)));
			column.setNullable(String.valueOf(1 == rsmd.isNullable(i)));

			// 获取列注释
			DatabaseMetaData dbmd = conn.getMetaData();
			ResultSet rs = dbmd.getColumns(null, null, tableName, null);
			while (rs.next()) {
				if (colName.equals(rs.getString("COLUMN_NAME"))) {
					String comments = rs.getString("REMARKS");
					column.setComments(StringUtil.asString(comments));
				}
			}
			// 获取主键列
			ResultSet rs2 = dbmd.getPrimaryKeys(null, null, tableName);
			while (rs2.next()) {
				if (colName.equals(rs2.getString("COLUMN_NAME"))) {
					column.setColumnKey("TRUE");
				}
			}
			lsColumns.add(column);
		}
		closeConnection(conn, stmt, resultSet);
		return lsColumns;
	}

	private List<Column> getColumns(String type, String maName, String tableName, String userName, String password,
			String driver, String url) throws Exception {

		String[] columns = type.split(",");
		String[] tables = tableName.split(",");
		Connection conn = getConnection(userName, password, driver, url);
		List<Column> lsColumns = new ArrayList<Column>(10);
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		for (String table : tables) {
			if (table.equals(""))
				continue;
			stmt = conn.prepareStatement("select *  from " + table + " where 1=0 ");
			resultSet = stmt.executeQuery();
			ResultSetMetaData rsmd = resultSet.getMetaData();
			int n = rsmd.getColumnCount();
			for (int i = 1; i <= n; i++) {
				int flag = 0;
				String colName = rsmd.getColumnName(i);
				for (int j = 0; j < columns.length; j++) {
					if (columns[j].equals(colName)) {
						flag = 1;
					}
				}
				if (flag == 0) {
					continue;
				}
				String fieldName = StringUtil.replaceUnderlineAndfirstToUpper(colName, "_", "");
				String dataType = rsmd.getColumnClassName(i);
				if ("java.math.BigDecimal".equals(dataType) && rsmd.getScale(i) == 0) {
					dataType = "Long";
				}
				if ("oracle.sql.CLOB".equals(dataType)) {
					dataType = "String";
				}
				if ("java.lang.Boolean".equals(dataType)) {
					dataType = "java.lang.Integer";
				}

				Column column = new Column();
				column.setName(colName);
				column.setJavaName(fieldName);
				column.setDataType(
						dataType.endsWith("Timestamp") || dataType.endsWith("Date") ? "java.util.Date" : dataType);
				column.setPrecision(String.valueOf(rsmd.getPrecision(i)));
				column.setScale(String.valueOf(rsmd.getScale(i)));
				column.setLength(String.valueOf(rsmd.getColumnDisplaySize(i)));
				column.setNullable(String.valueOf(1 == rsmd.isNullable(i)));

				// 获取列注释
				DatabaseMetaData dbmd = conn.getMetaData();
				ResultSet rs = dbmd.getColumns(null, null, table, null);
				while (rs.next()) {
					if (colName.equals(rs.getString("COLUMN_NAME"))) {
						String comments = rs.getString("REMARKS");
						column.setComments(StringUtil.asString(comments));
					}
				}
				// 获取主键列
				ResultSet rs2 = dbmd.getPrimaryKeys(null, null, table);
				while (rs2.next()) {
					if (colName.equals(rs2.getString("COLUMN_NAME"))) {
						column.setColumnKey("TRUE");
					}
				}
				if (column.getColumnKey().equals("TRUE") && !table.equals(maName)) {

					continue;
				}
				lsColumns.add(column);
			}
		}
		closeConnection(conn, stmt, resultSet);
		return lsColumns;
	}

	private Map<String, String> getRelKey(String tableName, String userName, String password, String driver, String url)
			throws Exception {
		Map<String, String> map = new HashMap<>();
		String[] tables = tableName.split(",");
		Connection conn = getConnection(userName, password, driver, url);
		List<Column> lsColumns = new ArrayList<Column>(10);
		PreparedStatement stmt = null;
		ResultSet resultSet = null;
		for (String table : tables) {
			stmt = conn.prepareStatement("select *  from " + table + " where 1=0 ");
			resultSet = stmt.executeQuery();
			ResultSetMetaData rsmd = resultSet.getMetaData();
			int n = rsmd.getColumnCount();
			for (int i = 1; i <= n; i++) {
				String colName = rsmd.getColumnName(i);
				DatabaseMetaData dbmd = conn.getMetaData();
				// 获取主键列
				ResultSet rs2 = dbmd.getPrimaryKeys(null, null, table);
				while (rs2.next()) {
					if (colName.equals(rs2.getString("COLUMN_NAME"))) {
						map.put(table, colName);
						break;
					}
				}
			}
		}
		closeConnection(conn, stmt, resultSet);
		return map;
	}

	private String getTableComment(String databaseName, String tableName, String userName, String password,
			String driver, String url) throws Exception {
		Connection conn = getConnection(userName, password, driver, url);
		PreparedStatement ps = conn
				.prepareStatement("Select TABLE_COMMENT from INFORMATION_SCHEMA.TABLES Where  table_schema = '"
						+ databaseName + "' AND table_name LIKE '" + tableName + "'");
		ResultSet rs = ps.executeQuery();
		String tableComment = null;
		while (rs.next()) {
			tableComment = rs.getString("TABLE_COMMENT");
		}
		closeConnection(conn, ps, rs);
		return tableComment == null ? "" : tableComment;
	}

}
